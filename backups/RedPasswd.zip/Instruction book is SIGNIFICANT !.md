Instruction book is SIGNIFICANT !

RP	README!!!

一款定向暴力破解工具,针对信息收集后,用目标的特征信息进行专用字典生成,让字典里的每一条数据都有包含目标特征的数据.

​	使用本工具需要一定的信息收集能力,例如,针对个体的特定日期,号码,名缩写等等,针对指定团体的名称缩写,特定日期,口号等,将此数据做成一个原始字典,用本程序对其进行指定方式组合,以高效验证可能的数据.

选项解释: 

1.基础模块:对生成的字典不做干预,可以限制最大生成数量 

2.万全模块:完全无限制,可能生成数据量庞大的字典,非必要请优先考虑其他模块 

3.非符模块:如果生成的数据首位是符号,那么此条数据将被清除 

4.字母模块:首位必须是字母,否则数据不会被保存到输出的字典 

5.大写模块:首位必须是大写字母,否则数据不会被保存到输出的字典

本程序仅供学习、交流,以及合法范围内的测试,切勿用作非法用途,否则一切责任、后果自负.

​																													Author: Stupid FQ

​	A directed brute force cracking tool, after collecting information, generates a special dictionary with the characteristic information of the target, so that every piece of data in the dictionary contains the data of the target characteristics.

The use of this tool requires certain information collection capabilities, such as specific date, number, name abbreviation, etc., for an individual, name abbreviation, specific date, slogan, etc., to make this data into a primitive dictionary, and combine it in a specified way with this program to efficiently verify possible data.

Options explained:

1. Basic module: Do not interfere with the generated dictionary, can limit the maximum number of generated

2. Universal module: Completely unlimited, may generate a large amount of data dictionary, non-necessary please give priority to other modules

3. Non-character module: If the first part of the generated data is a symbol, then this data will be cleared

4. Letter module: the first must be a letter, otherwise the data will not be saved to the output dictionary

5. Uppercase module: The first letter must be uppercase, otherwise the data will not be saved to the output dictionary

This program is only for learning, communication, and testing within the legal scope, do not use for illegal purposes, otherwise all responsibilities, consequences.

​																												 Author: Stupid FQ